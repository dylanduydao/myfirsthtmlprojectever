#/bin/bash
. /etc/profile.d/nodejs.sh
node $@
